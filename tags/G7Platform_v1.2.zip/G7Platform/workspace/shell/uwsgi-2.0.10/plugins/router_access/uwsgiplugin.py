NAME='router_access'
CFLAGS = []
LDFLAGS = []
LIBS = ['-lwrap']

REQUIRES = ['']

GCC_LIST = ['router_access']
