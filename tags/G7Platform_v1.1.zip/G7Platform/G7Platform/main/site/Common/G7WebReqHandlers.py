#-*- coding: UTF-8 -*-
__author__ = 'helios'
'''
    该类作为web请求模块
'''

from G7Platform.main.site.Common.G7ReqHandlers import *

class G7WebReqHandler(G7ReqHandler):
    """web请求基类"""
    pass
