<?php phpinfo(); ?>
<?php echo "hello php" ?>