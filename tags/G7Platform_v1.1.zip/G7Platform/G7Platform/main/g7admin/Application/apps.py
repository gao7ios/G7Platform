#-*- coding: UTF-8 -*-
__author__ = 'yuyang'

from django.apps import AppConfig

class ApplicationConfig(AppConfig):
    name = 'Application'
    verbose_name = '产品'