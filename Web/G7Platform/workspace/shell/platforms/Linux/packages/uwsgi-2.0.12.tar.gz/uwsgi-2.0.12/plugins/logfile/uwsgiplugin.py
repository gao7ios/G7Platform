NAME='logfile'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['logfile']
